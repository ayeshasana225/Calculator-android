package com.example.calculator;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText editText;
    private String currentInput = "";
    private double operand1 = Double.NaN;
    private String pendingOperation = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText = findViewById(R.id.editText);
    }

    public void onNumberClick(View view) {
        Button button = (Button) view;
        currentInput += button.getText().toString();
        editText.setText(currentInput);
    }

    public void onOperationClick(View view) {
        Button button = (Button) view;
        String operation = button.getText().toString();

        if (!currentInput.isEmpty()) {
            if (!Double.isNaN(operand1)) {
                operand1 = performOperation(operand1, Double.parseDouble(currentInput), pendingOperation);
                editText.setText(String.valueOf(operand1));
                currentInput = "";
            } else {
                operand1 = Double.parseDouble(currentInput);
                currentInput = "";
            }

            pendingOperation = operation;
        }
    }

    public void onEqualClick(View view) {
        if (!currentInput.isEmpty() && !Double.isNaN(operand1)) {
            operand1 = performOperation(operand1, Double.parseDouble(currentInput), pendingOperation);
            editText.setText(String.valueOf(operand1));
            currentInput = "";
            operand1 = Double.NaN;
            pendingOperation = "";
        }
    }

    public void onClearClick(View view) {
        currentInput = "";
        operand1 = Double.NaN;
        pendingOperation = "";
        editText.setText("0");
    }

    public void onDecimalClick(View view) {
        if (!currentInput.contains(".")) {
            currentInput += ".";
            editText.setText(currentInput);
        }
    }

    private double performOperation(double operand1, double operand2, String operation) {
        switch (operation) {
            case "+":
                return operand1 + operand2;
            case "-":
                return operand1 - operand2;
            case "*":
                return operand1 * operand2;
            case "/":
                if (operand2 != 0) {
                    return operand1 / operand2;
                } else {
                    // Handle division by zero
                    return Double.NaN;
                }
            default:
                return operand2;
        }
    }
}
